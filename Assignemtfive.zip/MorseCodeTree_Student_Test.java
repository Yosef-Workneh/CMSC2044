

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MorseCodeTree_Student_Test {

MorseCodeTree tree = new MorseCodeTree();

@Before
public void setUp() throws Exception {

}

@After
public void tearDown() throws Exception {

tree = null;

}

@Test
public void testInsert() {

tree.insert(".---", "1");


String letter = tree.fetch(".---");

assertEquals("1", letter);

}

@Test
public void testgetRoot() {

String root;

root = tree.getRoot().getData();

assertEquals("", root);

}

@Test
public void testSetRoot() {

String r;


assertEquals("", tree.getRoot().getData());


TreeNode<String> name = new TreeNode <String> ("Yosef");


tree.setRoot(name);

r = tree.getRoot().getData();

assertEquals("Yosef", r);
}

@Test
public void testFetch() {


String letter1;


letter1 = tree.fetch("-...");

assertEquals("b", letter1);


String letter2;


letter2 = tree.fetch("-..");

assertEquals("d", letter2);

}

}
