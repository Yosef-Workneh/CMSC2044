

public class TreeNode<T>
{
	T data;

	TreeNode<T> left, right;  

	public TreeNode (T dataNode)
	{  
		this.data = dataNode;
		this.left = null;
		this.right = null;
	}

	public TreeNode (TreeNode<T> node)
	{
		new TreeNode <T> (node);
	}

	public T getData()
	{
		return data;
	}

}

