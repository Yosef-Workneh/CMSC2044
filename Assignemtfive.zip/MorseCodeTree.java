


import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface <String>
{
	TreeNode <String> r = null; 

	String x; 

	public MorseCodeTree()
	{
		buildTree(); 
	}

	public TreeNode <String> getRoot()
	{
		return this.r;
	}
	
	public void setRoot(TreeNode <String> newNode) {

		r = newNode;  
	}

	@Override
	public void insert(String code, String letter)
	{

		addNode(r, code, letter);

		return;      
	}
	
	@Override
	public void addNode(TreeNode <String> root, String code, String letter)
	{  
		if(code.length() == 1)
		{
			if (code.equals("."))
			{
				root.left = new TreeNode <String>(letter);
			}

			else 
			{
				root.right = new TreeNode<String>(letter);
			}

			return;
		}
		else

		{  

			if(code.substring(0, 1).equals("."))
			{

				addNode(root.left, code.substring(1), letter);
			}


			else 
			{

				addNode(root.right, code.substring(1), letter);      
			}      
		}          
	}
	
	public String fetch(String code)
	{
		String letter = fetchNode(r, code);

		return letter;
	}


	public String fetchNode(TreeNode<String> root, String code)
	{  

		if(code.length() == 1)
		{

			if (code.equals("."))
			{
				x = root.left.getData();
			}

			else
			{
				x = root.right.getData();
			}
		}
		else
		{  

			if(code.substring(0, 1).equals("."))
			{
				fetchNode(root.left, code.substring(1));
			}

			else
			{

				fetchNode(root.right, code.substring(1));      
			}      
		}

		return x;  
	}
	

	public MorseCodeTree  delete(String data) throws UnsupportedOperationException {

		return null;
	}

	public MorseCodeTree update() throws UnsupportedOperationException {

		return null;
	}
	
	@Override
	public void buildTree()
	{

		r = new TreeNode<String>("");


		insert(".", "e"); insert("-", "t");


		insert("..", "i"); insert(".-", "a"); 
		insert("-.", "n"); insert("--", "m");


		insert("...", "s"); insert("..-", "u");
		insert(".-.", "r"); insert(".--", "w"); 
		insert("-..", "d");  insert("-.-", "k"); 
		insert("--.", "g");  insert("---", "o");


		insert("....", "h"); insert("...-", "v"); insert("..-.", "f");
		insert(".-..", "l"); insert(".--.", "p"); insert(".---", "j");
		insert("-...", "b"); insert("-..-", "x"); insert("-.-.", "c");
		insert("-.--", "y"); insert("--..", "z"); insert("--.-", "q");                  
	}




	public ArrayList <String> toArrayList()

	{
		ArrayList<String> tree = new ArrayList<String>();

		LNRoutputTraversal(r, tree);      

		return tree;
	}

	public void LNRoutputTraversal(TreeNode< String> root, ArrayList<String> list)
	{
		if(!(root == null))
		{
			LNRoutputTraversal(root.left, list);

			list.add(root.getData());

			LNRoutputTraversal(root.right, list);
		}
	}

}


