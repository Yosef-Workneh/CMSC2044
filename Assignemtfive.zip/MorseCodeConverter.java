

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter

{
	public static  MorseCodeTree MorseTree = new MorseCodeTree();

	public MorseCodeConverter()
	{

	}

	public static String convertToEnglish(String code)

	{
		String res = "";

		String [] word = code.split(" / ");


		for(int i = 0; i < word.length; i++)
		{  

			String [] letter = word[i].split(" ");

			for(int j = 0; j < letter.length; j++)
			{
				res += MorseTree.fetch(letter[j]);  
			}

			res += " ";
		}  

		res = res.trim();

		return res;
	}
	public static String convertToEnglish(File codeFile) throws FileNotFoundException
	{
		String res = "";

		ArrayList<String> l = new ArrayList<String>();

		Scanner input = new Scanner(codeFile);

		do {

			l.add(input.nextLine());
		}

		while (input.hasNext());

		input.close();


		for(int i = 0; i < l.size(); i++)
		{

			String [] word = l.get(i).split(" / ");

			for(int x = 0; x < word.length; x++)
			{

				String [] letter = word[x].split(" ");

				for(int j = 0; j < letter.length; j++)
				{

					res += MorseTree.fetch(letter[j]);  
				}


				res += " ";
			}
		}

		res =   res.trim();

		return res;
	}
	public static String printTree()
	{
		ArrayList<String> data = new ArrayList<String>();

		data = MorseTree.toArrayList();

		String x = "";

		for(int j = 0; j < data.size(); j ++)
		{
			x += data.get(j) + " ";  
		}

		return x.trim();
	}
}